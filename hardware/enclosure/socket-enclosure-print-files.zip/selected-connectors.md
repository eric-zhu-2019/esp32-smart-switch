# User-selected connectors

Selected 2026-11-20. These replace the earlier SCHURTER / Interpower references.

| Role | Quantity | Selected listing |
| --- | --- | --- |
| Power inlet | 1 module | [Amazon.ca B0FFS5SBZZ](https://www.amazon.ca/gp/product/B0FFS5SBZZ) |
| Controlled outlet | 4 outlet positions | [Amazon.ca B07WV7MTQH](https://www.amazon.ca/dp/B07WV7MTQH) |

Quantity above means installed outlet positions, not retail packs. Module type,
manufacturer/model, pack quantity, mounting method and dimensions have not yet
been verified. Do not assume these modules share the reference parts' cutouts.

Both Amazon.ca listings were inaccessible through the available web retrieval
on 2026-11-20. Exact-ASIN searches also returned no matching product information.
System Chrome was also requested, but browser control reported no connected
browsers. No mechanical or electrical specifications have been inferred from
similar parts.

## Information needed for the CAD revision

For each selected module, obtain a dimensioned drawing or measured dimensions:

- Required panel opening width/height, or diameter, and corner shape.
- Mounting screw count, hole diameter and center spacing, or snap-latch details.
- Permitted panel thickness and external flange dimensions.
- Depth behind the panel including terminals and insulated connections.
- Product photo/model to identify orientation and any switch/fuse-holder access.

Use the seller's dimension images or measurements of the actual received parts.
A listing's shipping/package dimensions are not a panel cutout specification.

## Existing files

`socket-enclosure.scad`, `socket-*-fit-check.stl`, and the current ZIP still contain
the previous SCHURTER 6100.3300 / Interpower 88261100 mounting geometry. Their mesh
and clearance checks remain valid only for that earlier geometry. They have NOT
been resized for these Amazon modules. Re-export all affected parts, recheck the
inner guard and terminal clearance, update previews and print a new fit coupon
once the required dimensions are available.

## Reinforcement revision

The reference enclosure now has 4 mm walls/floor, 6 mm mounting panels,
62 mm square pads, two 4 mm side gussets per mount, and a continuous top rim.
This strengthens the proposed geometry without establishing compatibility with
the selected connectors or a verified force rating. Mounting method, allowable
panel thickness, actual hardware, terminal clearances and printed load tests
remain pending. See the enclosure README for the test plan.
